export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDdUFNsabVqhUTcM9LZihk21R3y4SAMy54",
    authDomain: "milindcrud.firebaseio.com",
    databaseURL: "https://milindcrud.firebaseio.com",
    projectId: "milindcrud",
    storageBucket: "",
    messagingSenderId: "692864436113"
  }
};
